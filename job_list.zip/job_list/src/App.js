import React,{useState,useEffect} from 'react';
import data from './assets/data.json';
import JobBoardComponent from './components/JobBoardComponent';

console.log(data);
function App() {
  const [jobs,setJobs]=useState([]);
  const [filters,setFilters]=useState([]);
  useEffect(() => 
    setJobs(data),[]);
  console.log(jobs);

  const filterFunc=({role,level,tools,languages}) => {
    if(filters.length ===0){
      return true;
    }
    const tags = [role,level];
    if(languages){
        tags.push(...languages);
    }
    if(tools){
        tags.push(...tools);
    }
    

    return tags.some(tag => filters.includes(tag));
  }
  const handleTagClick=(tag) => {
    setFilters([...filters,tag]);
  };
  const filteredJobs=jobs.filter(filterFunc);
  

  return (
    <div className="App">
      <header className='bg-teal-500'>
        
  
        <img src='/images/bg-header-desktop.svg' alt=''/>
      </header>
      {
      
      jobs.length === 0 ? (
        <p>Jobs are Fetching...</p>

      ) : (
        filteredJobs.map((job) => (
          <JobBoardComponent 
          job={job} 
          key={job.id} 
          handleTagClick={handleTagClick} 
          />
        ))
      
      )
      }
      
    </div>
  );
}

export default App;
